/*
** EPITECH PROJECT, 2020
** rush.c
** File description:
** 
*/

void width_1(int x, int y)
{
    for (int counterW = 0; counterW < x; counterW++) {
        if (y != 1 && counterW < 1 && x > 1 && x != 1)
            my_putchar('A');
        else if (y != 1 && counterW == x-1 && x != 1)
            my_putchar('C');
        else
            my_putchar('B');
    }
    my_putchar('\n');
    return;
}

void width_2(int x, int y)
{
    for (int counterW = 0; counterW < x; counterW++) {
        if (y != 1 && counterW < 1 && x != 1)
            my_putchar('A');
        else if (y != 1 && counterW == x -1 && x != 1)
            my_putchar('C');
        else
            my_putchar('B');
    }
    my_putchar('\n');
    return;
}

void height(int y, int x)
{
    int counterH = 0;
    int printH = 0;

    while (0 <= printH && printH < y - 2) {
        counterH = 0;
        while (counterH < x) {
            if (counterH < 1 || counterH == x - 1)
                my_putchar('B');
            else {
                my_putchar(' ');
            }
            ++counterH;
        }
        ++printH;
        my_putchar('\n');
    }
    return;
}

void rush(int x, int y)
{
    int i = 0;
    char *arr = "Invalid size\n";

    if (x <= 0 || y <= 0 || x > 2147483647 || y > 2147483647) {
        while (arr[i] != '\0') {
            my_putchar(arr[i]);
            i++;
        }
        return;
    }
    else if (x != 1)
        width_1(x, y);
    else
        width_2(x, y);
    height(y, x);
    if (y > 1)
        width_2(x, y);
    return;
}
