/*
** EPITECH PROJECT, 2020
** rush-1-1
** File description:
** generates square
*/

void width_1(int x, int y)
{
    for (int counterW = 0; counterW < x; counterW++) {
        if (counterW < 1 || counterW == x - 1)
            my_putchar('o');
        else if (y == 1 && counterW > 1 || counterW < x - 2)
            my_putchar('-');
        else
            my_putchar('-');
    }
    my_putchar('\n');
    return;
}

void width_2(int x, int y)
{
    for (int counterW = 0; counterW < x; counterW++) {
        if (x == 1)
            my_putchar('o');
        else if (y != 1 && x != 1 && counterW < 1 || counterW == x - 1)
            my_putchar('o');
        else
            my_putchar('-');
    }
    my_putchar('\n');
}

void height(int x, int y)
{
    for (int printH = 0; printH >= 0 && printH < y - 2; printH++) {
        for (int counterH = 0; counterH < x; counterH++) {
            if (counterH < 1 || counterH == x - 1)
                my_putchar('|');
            else
                my_putchar(' ');
        }
        my_putchar('\n');
    }
    return;
}

void rush(int x, int y)
{
    int i = 0;
    char *arr = "Invalid size\n";
    
    if (x <= 0 || y <= 0 || x > 2147483647 || y > 2147483647) {
        while (arr[i] != '\0') {
            my_putchar(arr[i]);
            i++;
        }
        return;
    }
    else if (x != 1)
        width_1(x, y);
    else
        width_2(x, y);
    height(x, y);
    if (y > 1)
        width_2(x, y);
    return;
}
